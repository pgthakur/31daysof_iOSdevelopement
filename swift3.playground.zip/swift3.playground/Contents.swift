import UIKit

// iterators
var n = (1...5).makeIterator()
while let n = n.next(){
print("\(n)")
}
// Function
func add (x:Int, y:Int) ->Int{
    return x+y
}

func sum (_ x: Int, _ y: Int) -> Int {
    return x+y
}
print("sum:\(sum(5,4))")

print("add:\(add(x: 5, y: 13))")
 
func kuchh () -> Void{
    print("void function")
}
kuchh()

func getsum (_ x:Int, _ y:Int) -> Int{
    return x+y
}
func getsum (_ x:Double, _ y:Double) -> Double{
    return x+y
}
print("sum:\(getsum(4.7,6))")
// note:- you can use same function name when datatypes and return types are not same.
// inout parameters
func variable (_ num: inout Int) -> Void {
    print("num:\(num)")
    
}
var i4=5
variable(&i4)

// return multiple values

func twoMult (_ num:Int) -> (two:Int, three:Int){
    let two:Int = 2*num
    let three:Int = 3*num
    return (two, three)
}
let mult = twoMult (5)
print(" 2 mults:\(mult.two),\(mult.three)")

// variadic parameter
// in this accept unknown number of values

func variadic (_ numArr:Int ...) -> Int{
    var sum:Int = 0
    for item in numArr {
        sum += item
    }
    return sum
}
print("sum:\(variadic(1,10,100))")

// recursion
// recursion is just a act to calling function itself

func factorial (_ num:Int) -> Int{
    var result:Int = 0
    if num == 1 {
        return 1
    }
    else{
        result = num*factorial(num-1)
        return result
    }
}
print(factorial(4))
 
// store function in variable
func addby2 (_ num:Int) -> Int {
    return num+2
}
let inc = addby2(5)
print(inc)

