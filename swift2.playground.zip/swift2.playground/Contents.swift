import UIKit

// Ternary operator
// condition ? statement after true : statement after false
var age:Int=19
age>=21 ? print("you can marry") : print("you are a child")

// switch
let result:Int=29
switch result {
case 60...100 :
    print("1st division")
case 45...59 :
    print("2nd division")
case 30...44:
    print("3rd division")
default:
    print("better luck next time!")
}
// for
var array = [1,2,3,4,5]
for item in array {
    print(item)
}
for i in 1...5 {
    print("\(i)")
}
for item in 1...100 where item%4==0 {
    print("\(item)")
}
for item in 1...10 where item % 2 == 0 {
    print("Even:\(item)")
}
for item in 1...10 where item % 2 != 0{
    print("odd:\(item)")
}
for item in stride(from: 10, to: 0, by: -2) {
    print(item)
}
array.forEach{print($0)}
 // while
var n:Int=1
while n<10 {
    if   n % 2 == 0 {
       print(n)
    }
    n+=1
}
// repeat while
let magicNum:Int = Int.random(in: 1...10)
var Guess:Int = 0
repeat{
    print("Guess:\(Guess)")
    Guess+=1
}
while (magicNum != Guess)
print("Get magic number : \(magicNum)")


