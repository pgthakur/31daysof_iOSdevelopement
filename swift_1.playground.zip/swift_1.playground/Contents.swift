import UIKit

var str = "Hello, playground";
print(str);
/* you can use semicolon or not, it's not required but if you want then you can. */
// variable declaration
var string="prabhat"
// constant declaration
let string2="gaurav"
string = "prabhat gaurav"
/* variable is changed.but consatnt after declaration you can't change. */
// string2="thakur"
/* error: Cannot assign to value: 'string2' is a 'let' constant */
print(string)
print(string,string2)
// data types
var roll:Int=19107744
var age=20
print("min int \(Int64.min)")
print("max int \(Int64.max)")
var weight=67.250
var height:Float=5.7690
var weight2:Double=88.456
print(weight2)
print("min double \(Double.leastNormalMagnitude)")
print("max double \(Double.greatestFiniteMagnitude)")
print(height)
// float can store only upto 15 digits.
var pass:Bool=true
var grade:Character="A"
// Double to int
print("Double to int \(Int(height))")
// int to double
print("int to double \(Double(age))")
// double to float
print("double to float \(Float(weight2))")

// Math operators
print("9 + 6 = \(9+6)")
print("9 - 6 = \(9-6)")
print("9 * 6 = \(9*6)")
print("9 / 6 = \(9.0/6)")
print("9 % 6 = \(9%6)")

var num:Int=5
num=num+1
num+=1
num-=1 //num=num-1
num*=1 //num=num*1
num/=2 //num=num/2
num%=2 //num=num%2

// random
var rand=Int.random(in: 1...age)
print(rand)
var random=Double.random(in: 1.008...19.456)
print(random)
var randfloat=Float.random(in: 1.008...19.456)
print(randfloat)

// Math Functions

//absolute value
print(abs(-5.47))
// floor
print("Floor(5.67) = \(floor(5.67))")
// ceil function
print("ceil(4.56)=\(ceil(4.56))")
// round function
print("round(7.89)= \(round(7.89))")
// max function
print("maxof(2,6)=\(max(2, 6))")
// min function
print("minof(4,12)=\(min(4, 12))")
// power function
print("power of 2 is 5 = \(pow(2,5))")
// square root function
print("squareroot(16)= \(sqrt(16))")
//logarithmic function
print("log(2.71999)=\(log(2.7199))")

// IF/ELSE condition
var cgpa=7.5



if cgpa>9.0 {
 print("you are selected.")
  }
else if cgpa>=8.0 && cgpa<9.0{
    print("you are selected but you can improve your cgpa by \(9.0-cgpa)")
}
else if cgpa<8.0 && cgpa>=7.0{
    print("you are not selected but for next time you'll improve your cgpa by atleast by \(8.0-cgpa)")
}
else{
    print("try hard to improve your cgpa by \(8.0-cgpa) and next time you'll ensure your selection ")
}
